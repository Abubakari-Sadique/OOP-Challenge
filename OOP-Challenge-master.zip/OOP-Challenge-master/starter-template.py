class Pet:
    def __init__(self, name):
        self.name = name
        self.hunger = 5
        self.energy = 5
        self.happiness = 5
        self.tricks = []

    def eat(self):
        # TODO

    def sleep(self):
        # TODO

    def play(self):
        # TODO

    def train(self, trick):
        # TODO

    def show_tricks(self):
        # TODO

    def get_status(self):
        # TODO
